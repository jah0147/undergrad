clc; clear; close all; %clearing everything

% Having "%%" will section each part of code

%%
%Part 4 and 5
%Create Array t
t = -10:0.1:10;
 
%Create Outputs y = u(t) and y = r(t)
y_u = u(t,0);
y_r = r(t,0);

%subplot of u(t)
%subplot(1,2,1) %Commented out bc this was used in previous step
figure(1)
plot(t,u(t,0),'LineWidth',2)
title('Plot of u(t)');
ylabel('Amplitude');
xlabel('time(s)');
grid on;
ylim([-0.1,1.1]);

%%
%subplot of r(t)
%subplot(1,2,2) %Commented out bc this was used in previous step
figure(2)
plot(t,r(t,0),'LineWidth',2)
title('Plot of r(t)');
ylabel('Amplitude');
xlabel('time(s)');
grid on;

%%
tau = 1;
figure(3)
plot(t,p(t,tau),'LineWidth',2);
title('Plot of p(t,1)');
ylabel('Amplitude');
xlabel('time(s)');
grid on;
ylim([-0.1,1.1]);

%%
%Part 6
%x1 and x2 values
x1 = (r(t,0)-r(t-2,0))+3*u(t-2,0)+ 0.4*p(t,1);
x2 = r(t,0)-2*r(t-2,0)+4*u(t-2,0)+r(t-4,0)-4*u(t-4,0);

%%
%Plotting Figure 4
figure(4)
plot(t,x1,'LineWidth',2);
hold on;
title('Plot of x1');
ylabel('Amplitude');
xlabel('time(s)');
grid on;

%%
hold on;
plot(t,x2,'LineWidth',2,'LineStyle','--');
title('Plot of x2');
ylabel('Amplitude');
xlabel('time(s)');
grid on;
legend('x1','x2');
hold off;