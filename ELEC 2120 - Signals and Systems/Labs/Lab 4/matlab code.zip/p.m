function y = p(t,tau)
%Part 5
%function of Pt is 1 when 
%-tau/2 is <= t <= tau/2
%and 0 everwhere else
y = ((-tau/2)<=t)&(t<=(tau/2));
end


